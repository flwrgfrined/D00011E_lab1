CI_PROJECT="lab1"
CI_TESTBENCH="bcdcheck2_tb"
